import java.util.Scanner;

public class Q3 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("���� >> ");
		int age = sc.nextInt();
		
		if (age < 41) {
			System.out.println("�ʳ��Դϴ�.");
		} else if(age < 61) {
			System.out.println("�߳��Դϴ�.");
		} else {
			System.out.println("����Դϴ�.");
		}

	}

}
