import java.util.Scanner;

public class Q5 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("�� �� �Է� :");
		int i = sc.nextInt();
		System.out.print("��� ������ ��� :");
		int j = sc.nextInt();
		
		System.out.println(i+"��");
		
		for(int k = 1; k <= j; k++) {
			System.out.println(i + " * " + k + " = "  + (i*k));
	}
		
}
}