import java.util.Scanner;

public class Q6 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("�����Է� >> ");
		int num = sc.nextInt();
		
		int a = num1000;
		int b = num/100;

	}

}
